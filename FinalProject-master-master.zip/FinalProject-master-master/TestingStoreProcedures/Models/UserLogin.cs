﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace TestingStoreProcedures.Models
{
    public class UserLogin
    {
        [Display(Name = "ID #")]
        [Required(ErrorMessage = "Please Enter Your ID !")]
        public int ID { get; set; }


        [Display(Name = "Password")]
        [DataType(DataType.Password)]
        [Required(ErrorMessage = "Please Enter Your Password !")]
        public string Password { get; set; }
    }
}