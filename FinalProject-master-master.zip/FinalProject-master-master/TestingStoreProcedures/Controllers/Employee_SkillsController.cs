﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using TestingStoreProcedures.Models;

namespace TestingStoreProcedures.Controllers
{
    public class Employee_SkillsController : Controller
    {
        private HRMDATABASEEntities db = new HRMDATABASEEntities();

        // GET: Employee_Skills
        public ActionResult Index()
        {
            var employee_Skills = db.Employee_Skills.Include(e => e.Employee).Include(e => e.Ref_Skills).Include(e => e.Ref_Skill_Levels);
            return View(employee_Skills.ToList());
        }

        // GET: Employee_Skills/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee_Skills employee_Skills = db.Employee_Skills.Find(id);
            if (employee_Skills == null)
            {
                return HttpNotFound();
            }
            return View(employee_Skills);
        }

        // GET: Employee_Skills/Create
        public ActionResult Create()
        {
            ViewBag.employee_id = new SelectList(db.Employees, "employee_id", "employee_first_name");
            ViewBag.skill_id = new SelectList(db.Ref_Skills, "skill_id", "skill_name");
            ViewBag.skill_level_code = new SelectList(db.Ref_Skill_Levels, "skill_level_code", "skill_level_description");
            return View();
        }

        // POST: Employee_Skills/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "employee_id,skill_id,date_skill_acquired,skill_level_code")] Employee_Skills employee_Skills)
        {
            if (ModelState.IsValid)
            {
                db.Employee_Skills.Add(employee_Skills);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.employee_id = new SelectList(db.Employees, "employee_id", "employee_first_name", employee_Skills.employee_id);
            ViewBag.skill_id = new SelectList(db.Ref_Skills, "skill_id", "skill_name", employee_Skills.skill_id);
            ViewBag.skill_level_code = new SelectList(db.Ref_Skill_Levels, "skill_level_code", "skill_level_description", employee_Skills.skill_level_code);
            return View(employee_Skills);
        }

        // GET: Employee_Skills/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee_Skills employee_Skills = db.Employee_Skills.Find(id);
            if (employee_Skills == null)
            {
                return HttpNotFound();
            }
            ViewBag.employee_id = new SelectList(db.Employees, "employee_id", "employee_first_name", employee_Skills.employee_id);
            ViewBag.skill_id = new SelectList(db.Ref_Skills, "skill_id", "skill_name", employee_Skills.skill_id);
            ViewBag.skill_level_code = new SelectList(db.Ref_Skill_Levels, "skill_level_code", "skill_level_description", employee_Skills.skill_level_code);
            return View(employee_Skills);
        }

        // POST: Employee_Skills/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "employee_id,skill_id,date_skill_acquired,skill_level_code")] Employee_Skills employee_Skills)
        {
            if (ModelState.IsValid)
            {
                db.Entry(employee_Skills).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.employee_id = new SelectList(db.Employees, "employee_id", "employee_first_name", employee_Skills.employee_id);
            ViewBag.skill_id = new SelectList(db.Ref_Skills, "skill_id", "skill_name", employee_Skills.skill_id);
            ViewBag.skill_level_code = new SelectList(db.Ref_Skill_Levels, "skill_level_code", "skill_level_description", employee_Skills.skill_level_code);
            return View(employee_Skills);
        }

        // GET: Employee_Skills/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee_Skills employee_Skills = db.Employee_Skills.Find(id);
            if (employee_Skills == null)
            {
                return HttpNotFound();
            }
            return View(employee_Skills);
        }

        // POST: Employee_Skills/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Employee_Skills employee_Skills = db.Employee_Skills.Find(id);
            db.Employee_Skills.Remove(employee_Skills);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
