﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using TestingStoreProcedures.Models;

namespace TestingStoreProcedures.Controllers
{
    public class Training_HistoryController : Controller
    {
        private HRMDATABASEEntities db = new HRMDATABASEEntities();

        // GET: Training_History
        public ActionResult Index()
        {
            var training_History = db.Training_History.Include(t => t.Employee).Include(t => t.Ref_Courses);
            return View(training_History.ToList());
        }

        // GET: Training_History/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Training_History training_History = db.Training_History.Find(id);
            if (training_History == null)
            {
                return HttpNotFound();
            }
            return View(training_History);
        }

        // GET: Training_History/Create
        public ActionResult Create()
        {
            ViewBag.employee_id = new SelectList(db.Employees, "employee_id", "employee_first_name");
            ViewBag.course_id = new SelectList(db.Ref_Courses, "course_id", "course_name");
            return View();
        }

        // POST: Training_History/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "employee_id,course_id,date_of_course,results")] Training_History training_History)
        {
            if (ModelState.IsValid)
            {
                db.Training_History.Add(training_History);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.employee_id = new SelectList(db.Employees, "employee_id", "employee_first_name", training_History.employee_id);
            ViewBag.course_id = new SelectList(db.Ref_Courses, "course_id", "course_name", training_History.course_id);
            return View(training_History);
        }

        // GET: Training_History/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Training_History training_History = db.Training_History.Find(id);
            if (training_History == null)
            {
                return HttpNotFound();
            }
            ViewBag.employee_id = new SelectList(db.Employees, "employee_id", "employee_first_name", training_History.employee_id);
            ViewBag.course_id = new SelectList(db.Ref_Courses, "course_id", "course_name", training_History.course_id);
            return View(training_History);
        }

        // POST: Training_History/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "employee_id,course_id,date_of_course,results")] Training_History training_History)
        {
            if (ModelState.IsValid)
            {
                db.Entry(training_History).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.employee_id = new SelectList(db.Employees, "employee_id", "employee_first_name", training_History.employee_id);
            ViewBag.course_id = new SelectList(db.Ref_Courses, "course_id", "course_name", training_History.course_id);
            return View(training_History);
        }

        // GET: Training_History/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Training_History training_History = db.Training_History.Find(id);
            if (training_History == null)
            {
                return HttpNotFound();
            }
            return View(training_History);
        }

        // POST: Training_History/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Training_History training_History = db.Training_History.Find(id);
            db.Training_History.Remove(training_History);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
