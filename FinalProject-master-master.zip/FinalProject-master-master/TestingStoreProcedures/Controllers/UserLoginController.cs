﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.SqlClient;
using System.Web.Security;
using System.Configuration;
using TestingStoreProcedures.Models;

namespace TestingStoreProcedures.Controllers
{
    public class UserLoginController : Controller
    {
        private HRMDATABASEEntities db = new HRMDATABASEEntities();
        // GET: UserLogin
        public ActionResult Index()
        {
            return View();
        }   
        [AllowAnonymous]
        [HttpPost]
        public ActionResult Index(UserLogin ul)
        {
            string mainconn = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            SqlConnection sqlconn = new SqlConnection(mainconn);
            SqlCommand sqlcomm = new SqlCommand("[dbo].[login]");
            sqlconn.Open();
            sqlcomm.Connection = sqlconn;
            sqlcomm.CommandType = CommandType.StoredProcedure;
            sqlcomm.Parameters.AddWithValue("@Id", ul.ID);
            sqlcomm.Parameters.AddWithValue("@Password", ul.Password);
            SqlDataReader sdr = sqlcomm.ExecuteReader();
            if (sdr.Read())
            {
                Employee employee = db.Employees.Find(ul.ID);
                FormsAuthentication.SetAuthCookie(ul.ID.ToString(), true);
                Session["ID"] = ul.ID.ToString();
                Session["USER"] =employee.employee_first_name+" "+employee.employee_last_name;
                return RedirectToAction("Index","Dashboard");
            }
            else
            {
                ViewData["loginfail"] = "Login failed incorrect password or id !";
            }
            sqlconn.Close();
            return View();
        }

        public ActionResult Logout()
        {
            FormsAuthentication.SetAuthCookie(Session["ID"].ToString(), false);
            Session["ID"] = null;
            return RedirectToAction("Index", "UserLogin");
        }
    }
}