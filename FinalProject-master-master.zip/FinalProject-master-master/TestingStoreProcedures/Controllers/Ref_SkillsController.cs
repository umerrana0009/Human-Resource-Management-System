﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using TestingStoreProcedures.Models;

namespace TestingStoreProcedures.Controllers
{
    public class Ref_SkillsController : Controller
    {
        private HRMDATABASEEntities db = new HRMDATABASEEntities();

        // GET: Ref_Skills
        public ActionResult Index()
        {
            return View(db.Ref_Skills.ToList());
        }

        // GET: Ref_Skills/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Ref_Skills ref_Skills = db.Ref_Skills.Find(id);
            if (ref_Skills == null)
            {
                return HttpNotFound();
            }
            return View(ref_Skills);
        }

        // GET: Ref_Skills/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Ref_Skills/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "skill_id,skill_name,skill_description")] Ref_Skills ref_Skills)
        {
            if (ModelState.IsValid)
            {
                db.Ref_Skills.Add(ref_Skills);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(ref_Skills);
        }

        // GET: Ref_Skills/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Ref_Skills ref_Skills = db.Ref_Skills.Find(id);
            if (ref_Skills == null)
            {
                return HttpNotFound();
            }
            return View(ref_Skills);
        }

        // POST: Ref_Skills/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "skill_id,skill_name,skill_description")] Ref_Skills ref_Skills)
        {
            if (ModelState.IsValid)
            {
                db.Entry(ref_Skills).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(ref_Skills);
        }

        // GET: Ref_Skills/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Ref_Skills ref_Skills = db.Ref_Skills.Find(id);
            if (ref_Skills == null)
            {
                return HttpNotFound();
            }
            return View(ref_Skills);
        }

        // POST: Ref_Skills/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Ref_Skills ref_Skills = db.Ref_Skills.Find(id);
            db.Ref_Skills.Remove(ref_Skills);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
