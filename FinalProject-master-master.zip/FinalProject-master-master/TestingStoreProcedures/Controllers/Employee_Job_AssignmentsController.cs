﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using TestingStoreProcedures.Models;

namespace TestingStoreProcedures.Controllers
{
    public class Employee_Job_AssignmentsController : Controller
    {
        private HRMDATABASEEntities db = new HRMDATABASEEntities();

        // GET: Employee_Job_Assignments
        public ActionResult Index()
        {
            var employee_Job_Assignments = db.Employee_Job_Assignments.Include(e => e.Department).Include(e => e.Employee).Include(e => e.Ref_Job_Code).Include(e => e.Employee1);
            return View(employee_Job_Assignments.ToList());
        }

        // GET: Employee_Job_Assignments/Details/5
        public ActionResult Details(int? id1,DateTime? id2,int? id3)
        {
            if (id1 == null && id2 == null && id3 == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee_Job_Assignments employee_Job_Assignments = db.Employee_Job_Assignments.Find(id1,id2,id3);
            if (employee_Job_Assignments == null)
            {
                return HttpNotFound();
            }
            return View(employee_Job_Assignments);
        }

        // GET: Employee_Job_Assignments/Create
        public ActionResult Create()
        {
            ViewBag.department_id = new SelectList(db.Departments, "department_id", "department_name");
            ViewBag.employee_id = new SelectList(db.Employees, "employee_id", "employee_first_name");
            ViewBag.job_code = new SelectList(db.Ref_Job_Code, "job_code", "job_title");
            ViewBag.supervisor_employee_id = new SelectList(db.Employees, "employee_id", "employee_first_name");
            return View();
        }

        // POST: Employee_Job_Assignments/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "employee_id,date_started,department_id,job_code,supervisor_employee_id,date_finished,assignment_details")] Employee_Job_Assignments employee_Job_Assignments)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    db.Employee_Job_Assignments.Add(employee_Job_Assignments);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }

                ViewBag.department_id = new SelectList(db.Departments, "department_id", "department_name", employee_Job_Assignments.department_id);
                ViewBag.employee_id = new SelectList(db.Employees, "employee_id", "employee_first_name", employee_Job_Assignments.employee_id);
                ViewBag.job_code = new SelectList(db.Ref_Job_Code, "job_code", "job_title", employee_Job_Assignments.job_code);
                ViewBag.supervisor_employee_id = new SelectList(db.Employees, "employee_id", "employee_first_name", employee_Job_Assignments.supervisor_employee_id);
                return View(employee_Job_Assignments);
            }
            catch
            {
                ViewBag.already = "Job Already Assigned";
                return View(employee_Job_Assignments);
            }
        }

        // GET: Employee_Job_Assignments/Edit/5
        public ActionResult Edit(int? id1, DateTime? id2, int? id3)
        {
            if (id1 == null && id2 == null && id3 == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee_Job_Assignments employee_Job_Assignments = db.Employee_Job_Assignments.Find( id1,id2,id3);
            if (employee_Job_Assignments == null)
            {
                return HttpNotFound();
            }
            ViewBag.department_id = new SelectList(db.Departments, "department_id", "department_name", employee_Job_Assignments.department_id);
            ViewBag.employee_id = new SelectList(db.Employees, "employee_id", "employee_first_name", employee_Job_Assignments.employee_id);
            ViewBag.job_code = new SelectList(db.Ref_Job_Code, "job_code", "job_title", employee_Job_Assignments.job_code);
            ViewBag.supervisor_employee_id = new SelectList(db.Employees, "employee_id", "employee_first_name", employee_Job_Assignments.supervisor_employee_id);
            return View(employee_Job_Assignments);
        }

        // POST: Employee_Job_Assignments/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "employee_id,date_started,department_id,job_code,supervisor_employee_id,date_finished,assignment_details")] Employee_Job_Assignments employee_Job_Assignments)
        {
            if (ModelState.IsValid)
            {
                db.Entry(employee_Job_Assignments).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.department_id = new SelectList(db.Departments, "department_id", "department_name", employee_Job_Assignments.department_id);
            ViewBag.employee_id = new SelectList(db.Employees, "employee_id", "employee_first_name", employee_Job_Assignments.employee_id);
            ViewBag.job_code = new SelectList(db.Ref_Job_Code, "job_code", "job_title", employee_Job_Assignments.job_code);
            ViewBag.supervisor_employee_id = new SelectList(db.Employees, "employee_id", "employee_first_name", employee_Job_Assignments.supervisor_employee_id);
            return View(employee_Job_Assignments);
        }

        // GET: Employee_Job_Assignments/Delete/5
        public ActionResult Delete(int? id1, DateTime? id2, int? id3)
        {
            if (id1 == null && id2 == null && id3 == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Employee_Job_Assignments employee_Job_Assignments = db.Employee_Job_Assignments.Find(id1,id2,id3);
            if (employee_Job_Assignments == null)
            {
                return HttpNotFound();
            }
            return View(employee_Job_Assignments);
        }

        // POST: Employee_Job_Assignments/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? id1, DateTime? id2, int? id3)
        {
            Employee_Job_Assignments employee_Job_Assignments = db.Employee_Job_Assignments.Find(id1,id2,id3);
            db.Employee_Job_Assignments.Remove(employee_Job_Assignments);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
