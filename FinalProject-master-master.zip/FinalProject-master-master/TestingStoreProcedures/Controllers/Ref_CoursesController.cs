﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using TestingStoreProcedures.Models;

namespace TestingStoreProcedures.Controllers
{
    public class Ref_CoursesController : Controller
    {
        private HRMDATABASEEntities db = new HRMDATABASEEntities();

        // GET: Ref_Courses
        public ActionResult Index()
        {
            return View(db.Ref_Courses.ToList());
        }

        // GET: Ref_Courses/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Ref_Courses ref_Courses = db.Ref_Courses.Find(id);
            if (ref_Courses == null)
            {
                return HttpNotFound();
            }
            return View(ref_Courses);
        }

        // GET: Ref_Courses/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Ref_Courses/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "course_id,course_name,course_description")] Ref_Courses ref_Courses)
        {
            if (ModelState.IsValid)
            {
                db.Ref_Courses.Add(ref_Courses);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(ref_Courses);
        }

        // GET: Ref_Courses/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Ref_Courses ref_Courses = db.Ref_Courses.Find(id);
            if (ref_Courses == null)
            {
                return HttpNotFound();
            }
            return View(ref_Courses);
        }

        // POST: Ref_Courses/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "course_id,course_name,course_description")] Ref_Courses ref_Courses)
        {
            if (ModelState.IsValid)
            {
                db.Entry(ref_Courses).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(ref_Courses);
        }

        // GET: Ref_Courses/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Ref_Courses ref_Courses = db.Ref_Courses.Find(id);
            if (ref_Courses == null)
            {
                return HttpNotFound();
            }
            return View(ref_Courses);
        }

        // POST: Ref_Courses/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Ref_Courses ref_Courses = db.Ref_Courses.Find(id);
            db.Ref_Courses.Remove(ref_Courses);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
