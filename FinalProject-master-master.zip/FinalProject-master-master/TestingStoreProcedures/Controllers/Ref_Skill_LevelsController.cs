﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using TestingStoreProcedures.Models;

namespace TestingStoreProcedures.Controllers
{
    public class Ref_Skill_LevelsController : Controller
    {
        private HRMDATABASEEntities db = new HRMDATABASEEntities();

        // GET: Ref_Skill_Levels
        public ActionResult Index()
        {
            return View(db.Ref_Skill_Levels.ToList());
        }

        // GET: Ref_Skill_Levels/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Ref_Skill_Levels ref_Skill_Levels = db.Ref_Skill_Levels.Find(id);
            if (ref_Skill_Levels == null)
            {
                return HttpNotFound();
            }
            return View(ref_Skill_Levels);
        }

        // GET: Ref_Skill_Levels/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Ref_Skill_Levels/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "skill_level_code,skill_level_description")] Ref_Skill_Levels ref_Skill_Levels)
        {
            if (ModelState.IsValid)
            {
                db.Ref_Skill_Levels.Add(ref_Skill_Levels);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(ref_Skill_Levels);
        }

        // GET: Ref_Skill_Levels/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Ref_Skill_Levels ref_Skill_Levels = db.Ref_Skill_Levels.Find(id);
            if (ref_Skill_Levels == null)
            {
                return HttpNotFound();
            }
            return View(ref_Skill_Levels);
        }

        // POST: Ref_Skill_Levels/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "skill_level_code,skill_level_description")] Ref_Skill_Levels ref_Skill_Levels)
        {
            if (ModelState.IsValid)
            {
                db.Entry(ref_Skill_Levels).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(ref_Skill_Levels);
        }

        // GET: Ref_Skill_Levels/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Ref_Skill_Levels ref_Skill_Levels = db.Ref_Skill_Levels.Find(id);
            if (ref_Skill_Levels == null)
            {
                return HttpNotFound();
            }
            return View(ref_Skill_Levels);
        }

        // POST: Ref_Skill_Levels/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Ref_Skill_Levels ref_Skill_Levels = db.Ref_Skill_Levels.Find(id);
            db.Ref_Skill_Levels.Remove(ref_Skill_Levels);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
