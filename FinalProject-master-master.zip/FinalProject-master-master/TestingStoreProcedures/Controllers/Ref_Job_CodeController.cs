﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using TestingStoreProcedures.Models;

namespace TestingStoreProcedures.Controllers
{
    public class Ref_Job_CodeController : Controller
    {
        private HRMDATABASEEntities db = new HRMDATABASEEntities();

        // GET: Ref_Job_Code
        public ActionResult Index()
        {
            return View(db.Ref_Job_Code.ToList());
        }

        // GET: Ref_Job_Code/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Ref_Job_Code ref_Job_Code = db.Ref_Job_Code.Find(id);
            if (ref_Job_Code == null)
            {
                return HttpNotFound();
            }
            return View(ref_Job_Code);
        }

        // GET: Ref_Job_Code/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Ref_Job_Code/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "job_code,job_title,job_description,salary_minimum,salary_maximum")] Ref_Job_Code ref_Job_Code)
        {
            if (ModelState.IsValid)
            {
                db.Ref_Job_Code.Add(ref_Job_Code);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(ref_Job_Code);
        }

        // GET: Ref_Job_Code/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Ref_Job_Code ref_Job_Code = db.Ref_Job_Code.Find(id);
            if (ref_Job_Code == null)
            {
                return HttpNotFound();
            }
            return View(ref_Job_Code);
        }

        // POST: Ref_Job_Code/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "job_code,job_title,job_description,salary_minimum,salary_maximum")] Ref_Job_Code ref_Job_Code)
        {
            if (ModelState.IsValid)
            {
                db.Entry(ref_Job_Code).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(ref_Job_Code);
        }

        // GET: Ref_Job_Code/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Ref_Job_Code ref_Job_Code = db.Ref_Job_Code.Find(id);
            if (ref_Job_Code == null)
            {
                return HttpNotFound();
            }
            return View(ref_Job_Code);
        }

        // POST: Ref_Job_Code/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Ref_Job_Code ref_Job_Code = db.Ref_Job_Code.Find(id);
            db.Ref_Job_Code.Remove(ref_Job_Code);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
