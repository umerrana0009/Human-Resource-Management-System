﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TestingStoreProcedures.Models;

namespace TestingStoreProcedures.Controllers
{
    public class DashboardController : Controller
    {
        private HRMDATABASEEntities db = new HRMDATABASEEntities();
        // GET: Dashboard
        public ActionResult Index()
        {
            ViewBag.EmployeeCount = db.Employees.Count();
            ViewBag.CounrtiesCount = db.Countries.Count();
            ViewBag.ProjectCount = db.Ref_Job_Code.Count();
            return View();
        }
    }
}