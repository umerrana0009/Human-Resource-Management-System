﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using TestingStoreProcedures.Models;

namespace TestingStoreProcedures.Controllers
{
    public class Performance_ReviewsController : Controller
    {
        private HRMDATABASEEntities db = new HRMDATABASEEntities();

        // GET: Performance_Reviews
        public ActionResult Index()
        {
            var performance_Reviews = db.Performance_Reviews.Include(p => p.Employee).Include(p => p.Employee1);
            return View(performance_Reviews.ToList());
        }

        // GET: Performance_Reviews/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Performance_Reviews performance_Reviews = db.Performance_Reviews.Find(id);
            if (performance_Reviews == null)
            {
                return HttpNotFound();
            }
            return View(performance_Reviews);
        }

        // GET: Performance_Reviews/Create
        public ActionResult Create()
        {
            ViewBag.employee_id = new SelectList(db.Employees, "employee_id", "employee_first_name");
            ViewBag.reviewed_by_employee_id = new SelectList(db.Employees, "employee_id", "employee_first_name");
            return View();
        }

        // POST: Performance_Reviews/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "employee_id,date_of_review,reviewed_by_employee_id,comments_by_reviewer,comments_by_employee")] Performance_Reviews performance_Reviews)
        {
            if (ModelState.IsValid)
            {
                db.Performance_Reviews.Add(performance_Reviews);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.employee_id = new SelectList(db.Employees, "employee_id", "employee_first_name", performance_Reviews.employee_id);
            ViewBag.reviewed_by_employee_id = new SelectList(db.Employees, "employee_id", "employee_first_name", performance_Reviews.reviewed_by_employee_id);
            return View(performance_Reviews);
        }

        // GET: Performance_Reviews/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Performance_Reviews performance_Reviews = db.Performance_Reviews.Find(id);
            if (performance_Reviews == null)
            {
                return HttpNotFound();
            }
            ViewBag.employee_id = new SelectList(db.Employees, "employee_id", "employee_first_name", performance_Reviews.employee_id);
            ViewBag.reviewed_by_employee_id = new SelectList(db.Employees, "employee_id", "employee_first_name", performance_Reviews.reviewed_by_employee_id);
            return View(performance_Reviews);
        }

        // POST: Performance_Reviews/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "employee_id,date_of_review,reviewed_by_employee_id,comments_by_reviewer,comments_by_employee")] Performance_Reviews performance_Reviews)
        {
            if (ModelState.IsValid)
            {
                db.Entry(performance_Reviews).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.employee_id = new SelectList(db.Employees, "employee_id", "employee_first_name", performance_Reviews.employee_id);
            ViewBag.reviewed_by_employee_id = new SelectList(db.Employees, "employee_id", "employee_first_name", performance_Reviews.reviewed_by_employee_id);
            return View(performance_Reviews);
        }

        // GET: Performance_Reviews/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Performance_Reviews performance_Reviews = db.Performance_Reviews.Find(id);
            if (performance_Reviews == null)
            {
                return HttpNotFound();
            }
            return View(performance_Reviews);
        }

        // POST: Performance_Reviews/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Performance_Reviews performance_Reviews = db.Performance_Reviews.Find(id);
            db.Performance_Reviews.Remove(performance_Reviews);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
